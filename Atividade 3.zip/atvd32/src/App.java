
public static void main(String[] args) throws Exception {
char[][] matriz = {
{'c', 'a', 'i', 'o'},
{' ', 'd', 'e',' '},
{' ', 'o', 'l','i'},
{'v', 'e', 'i','r'},
{'a', ' ', 'l','a'},
{'v', 'o', 'r',' '},
};

for(char[] linha:matriz) {
    for(char coluna:linha) {
        System.out.print(coluna);
    }
}
    }
