import java.util.Scanner;
public static void main(String[] args) throws Exception {
    Scanner sc = new Scanner(System.in);
        int[][] matriz = new int[5][5];
        for(int l = 0; l < 5; l++) {
            for (int c = 0; c < 5; c++) {
                System.out.print("Elemento [" + l + "][" + c + "]: ");
                matriz[l][c] = sc.nextInt();
            }
        }
        int me = matriz[0][0];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (matriz[i][j] > me) {
                    me = matriz[i][j];
                }
            }
        }
        System.out.println("O maior elemento da matriz é: " + me);
        sc.close();
    }
