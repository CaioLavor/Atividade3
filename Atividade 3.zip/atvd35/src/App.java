public static void main(String[] args) throws Exception {
    double[][] matriz = {
        {1.5, 2.3, 3.2},
        {4.1, 5.7, 6.4},
        {7.9, 8.6, 9.0}
    };
    for (int l = 0; l < 3; l++) {
        double soma = 0;
        for (int c = 0; c < 3; c++) {
            soma += matriz[l][c];
        }
        System.out.println("Soma de cada linha " + (l + 1) + ": " + soma);
    }
    }
