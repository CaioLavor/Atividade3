import java.util.Scanner;
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int[] vet = new int[10]; 

        for (int i = 0; i < 10; i ++) {
            System.out.print("Digite o valor desejado para a posição " + i + " do vetor: ");
            vet[i] = sc.nextInt();
        }
        for(int i = 0; i < 10; i ++){
            System.out.println("Valor da posição " + i + " do vetor: " + vet[i]);
        }
        sc.close();
    }
