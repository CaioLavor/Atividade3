import java.util.Scanner;

public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int[] vet = {12, 5, 13, 6, 18, 20, 19, 22, 23, 66};

        System.out.print("Vetor: ");
        for (int i = 0; i < vet.length; i++) {
            System.out.println(vet[i] + " ");
        }

        System.out.print("Digite um valor para buscar no vetor: ");
        int vp = sc.nextInt();
        boolean encontrado = false;
        for (int i = 0; i < vet.length; i++) {
            if (vet[i] == vp) {
                System.out.println("O valor " + vp + " foi encontrado na posição " + i + " do vetor.");
                encontrado = true;
            }
        }
        if (encontrado == false) {
            System.out.println("O valor " + vp + " não existe no vetor.");
        }
        sc.close();
    }
